
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;

public class BancoDeDados {

    private static final String URL = "jdbc:mysql://127.0.0.1:3306/javasbank";
    private static final String USER = "root";
    private static final String PASSWORD = "senac@2025";

    public static Connection conectar() {
        try {
            // Classe do driver pode ser omitida em versões recentes do JDBC
            return DriverManager.getConnection(URL, USER, PASSWORD);
        } catch (SQLException e) {
            System.out.println("Erro ao conectar ao banco: " + e.getMessage());
            return null;
        }
    }

    public static boolean autenticarUsuario(String login, String senha) {
        String sql = "SELECT l.id FROM usuario l JOIN senha s ON l.id = s.id_usuario WHERE l.login = ? AND s.senha = ?";

        try (Connection conn = conectar(); PreparedStatement ps = conn.prepareStatement(sql)) {

            ps.setString(1, login);
            ps.setString(2, senha);

            try (ResultSet rs = ps.executeQuery()) {
                return rs.next(); // Se retornar linha, login/senha existem e conferem
            }

        } catch (SQLException e) {
            System.out.println("Erro ao autenticar: " + e.getMessage());
            return false;
        }
    }
}
